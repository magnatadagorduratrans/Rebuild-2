package com.rebuilt.zwhisper;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelUuid;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int REQ=42;
    static final ParcelUuid FE2C=ParcelUuid.fromString("0000fe2c-0000-1000-8000-00805f9b34fb");
    BluetoothLeScanner scanner; boolean scanning=false, fastOnly=false;
    LinearLayout list; TextView status; Button scanButton, modeButton;
    final Map<String,TextView> rows=new LinkedHashMap<>();

    @Override public void onCreate(Bundle b){super.onCreate(b); buildUi(); requestPermissionsIfNeeded();}
    void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,24,24,24); root.setBackgroundColor(0xFF101014);
        TextView title=new TextView(this); title.setText("ZWhisper Rebuilt"); title.setTextSize(24); title.setTextColor(0xFFFFFFFF); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        status=new TextView(this); status.setText("Ready"); status.setTextColor(0xFFCCCCCC); status.setPadding(0,12,0,12); root.addView(status);
        modeButton=new Button(this); modeButton.setText("Mode: All BLE"); modeButton.setOnClickListener(v->{fastOnly=!fastOnly; modeButton.setText(fastOnly?"Mode: Fast Pair (FE2C)":"Mode: All BLE"); if(scanning){stop(); start();}}); root.addView(modeButton);
        scanButton=new Button(this); scanButton.setText("START SCAN"); scanButton.setOnClickListener(v->{if(scanning)stop();else start();}); root.addView(scanButton);
        ScrollView sv=new ScrollView(this); list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); sv.addView(list); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    void requestPermissionsIfNeeded(){
        if(Build.VERSION.SDK_INT>=31){if(checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},REQ);}
        else if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ);
    }
    boolean perms(){return Build.VERSION.SDK_INT<31 || (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED);}
    void start(){
        if(!perms()){requestPermissionsIfNeeded(); status.setText("Bluetooth scan permission required"); return;}
        BluetoothManager bm=(BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE); BluetoothAdapter ba=bm.getAdapter();
        if(ba==null || !ba.isEnabled()){status.setText("Bluetooth is disabled"); return;}
        scanner=ba.getBluetoothLeScanner(); if(scanner==null){status.setText("BluetoothLeScanner is null");return;}
        rows.clear(); list.removeAllViews(); scanning=true; scanButton.setText("STOP SCAN"); status.setText(fastOnly?"Scanning Fast Pair (FE2C)...":"Scanning ALL BLE...");
        ScanSettings settings=new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).setReportDelay(0).build();
        List<ScanFilter> filters=null;
        if(fastOnly) filters=Collections.singletonList(new ScanFilter.Builder().setServiceUuid(FE2C).build());
        scanner.startScan(filters,settings,callback);
    }
    void stop(){if(scanner!=null && scanning){try{scanner.stopScan(callback);}catch(SecurityException ignored){} } scanning=false; scanButton.setText("START SCAN"); status.setText("Stopped");}
    final ScanCallback callback=new ScanCallback(){
        @Override public void onScanResult(int type,ScanResult r){handle(r);}
        @Override public void onBatchScanResults(List<ScanResult> rs){for(ScanResult r:rs)handle(r);}
        @Override public void onScanFailed(int e){scanning=false; runOnUiThread(()->{scanButton.setText("START SCAN");status.setText("Scan failed: error "+e);});}
    };
    void handle(ScanResult r){
        ScanRecord rec=r.getScanRecord(); if(rec==null)return;
        byte[] sd=rec.getServiceData(FE2C); if(fastOnly && sd==null)return;
        String addr; try{addr=r.getDevice().getAddress();}catch(SecurityException e){addr="permission denied";}
        String name=rec.getDeviceName(); if(name==null)name="(unnamed)";
        String key=addr+"|"+name;
        final String text=name+"\n"+addr+"   RSSI "+r.getRssi()+" dBm\n"+(sd==null?"Service Data FE2C: none":"FE2C: "+hex(sd));
        runOnUiThread(()->{TextView row=rows.get(key); if(row==null){row=new TextView(this);row.setTextColor(0xFFE8E8E8);row.setTextSize(16);row.setPadding(8,14,8,14);rows.put(key,row);list.addView(row);} row.setText(text);status.setText((fastOnly?"Fast Pair":"All BLE")+" — "+rows.size()+" device(s)");});
    }
    static String hex(byte[] b){StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(Locale.US,"%02X ",x&255));return s.toString().trim();}
    @Override protected void onDestroy(){stop();super.onDestroy();}
}
